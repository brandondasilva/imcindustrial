<?php get_header(); ?>

<navbar></navbar>
<ui-view></ui-view>
<bottom></bottom>

<?php get_footer(); ?>
