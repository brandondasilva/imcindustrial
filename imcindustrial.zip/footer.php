
  <?php wp_footer(); ?>
  
  <script src="http://maps.google.com/maps/api/js?key=AIzaSyAX3qnbwPxZP90loC35305WkYY8QV_Ow-Y"></script>
</body>
</html>
